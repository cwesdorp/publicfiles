package nl.chriswesdorp.twixleft.model;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.PostUpdate;

/**
 *
 * @author c.wesdorp
 */
public class CountryListener {

    @PostUpdate
    public void postUpdate(Object entity) {
        try {
            InitialContext initialContext = new InitialContext();
            String appName = (String) initialContext.lookup("java:app/AppName");

            StringBuilder sb = new StringBuilder("From CountryListener: ").append(appName).append(System.lineSeparator());

            for (StackTraceElement ste : Thread.currentThread().getStackTrace()) {
                if (ste.getClassName().startsWith("nl.chriswesdorp")) {
                    sb.append("    ").append(ste.toString()).append(System.lineSeparator());
                }
            }

            System.out.println(sb.toString());
        } catch (NamingException ex) {
            Logger.getLogger(CountryListener.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
