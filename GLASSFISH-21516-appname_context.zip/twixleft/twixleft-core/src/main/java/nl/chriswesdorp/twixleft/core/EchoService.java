package nl.chriswesdorp.twixleft.core;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import nl.chriswesdorp.twixleft.api.EchoServiceRemote;
import nl.chriswesdorp.twixleft.model.Country;

/**
 *
 * @author c.wesdorp
 */
@Stateless
@Remote(value = EchoServiceRemote.class)
public class EchoService implements EchoServiceRemote {

    @PersistenceContext(name = "twixleft")
    EntityManager em;

    @Override
    public String echo(String input) {
        try {
            InitialContext initialContext = new InitialContext();
            String appName = (String) initialContext.lookup("java:app/AppName");

            return new StringBuilder(appName).append(": echo: ").append(input).toString();
        } catch (NamingException ex) {
            Logger.getLogger(EchoService.class.getName()).log(Level.SEVERE, null, ex);
        }

        return "NamingException";
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public String updateCountry(Long id, String description) {
        Country country = em.find(Country.class, id);
        country.setDescription(description);

        return description;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public String updateCountryWithFlush(Long id, String description) {
        Country country = em.find(Country.class, id);
        country.setDescription(description);
        em.flush();

        return description;
    }

}
