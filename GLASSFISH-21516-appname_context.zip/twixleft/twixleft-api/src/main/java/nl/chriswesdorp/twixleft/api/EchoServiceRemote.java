package nl.chriswesdorp.twixleft.api;

/**
 *
 * @author c.wesdorp
 */
public interface EchoServiceRemote {

    String echo(String input);

    String updateCountry(Long id, String description);

    String updateCountryWithFlush(Long id, String description);
    
}
