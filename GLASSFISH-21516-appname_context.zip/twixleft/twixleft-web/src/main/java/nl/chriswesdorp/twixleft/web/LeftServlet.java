package nl.chriswesdorp.twixleft.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import nl.chriswesdorp.twixleft.api.EchoServiceRemote;

/**
 *
 * @author c.wesdorp
 */
@WebServlet(urlPatterns = "/left")
public class LeftServlet extends HttpServlet {

    @EJB EchoServiceRemote echoService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String input = req.getParameter("input");
        String output = echoService.echo(input);

        resp.setContentType("text/plain");
        resp.getWriter().write(output);
        resp.flushBuffer();
    }



}
