create table countries (
    id int not null primary key,
    version int not null,
    code varchar(255),
    description varchar(255)
);

insert into countries values (1, 1, 'NL', 'The Netherlands');
insert into countries values (2, 1, 'BE', 'Belgium');
insert into countries values (3, 1, 'DE', 'Germany');
