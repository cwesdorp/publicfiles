package nl.chriswesdorp.twixright.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import nl.chriswesdorp.twixleft.api.EchoServiceRemote;

/**
 *
 * @author c.wesdorp
 */
@WebServlet(urlPatterns = "/right")
public class RightServlet extends HttpServlet {

    @EJB EchoServiceRemote echoService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        String input = req.getParameter("input");

        String output = "";
        if (action == null || action.equals("")) {
            output = echoService.echo(input);

        } else if (action.equals("update")) {
            Long id = Long.valueOf(req.getParameter("id"));
            output = echoService.updateCountry(id, input);

        } else if (action.equals("updateFlush")) {
            Long id = Long.valueOf(req.getParameter("id"));
            output = echoService.updateCountryWithFlush(id, input);

        }

        resp.setContentType("text/plain");
        resp.getWriter().write(output);
        resp.flushBuffer();
    }




}
